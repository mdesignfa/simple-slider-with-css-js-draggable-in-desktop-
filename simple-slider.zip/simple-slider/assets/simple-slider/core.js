function is_device_touch(){
    if ("ontouchstart" in document.documentElement) {
        return true;
    }
    else return false;
}//To check Touch devices!

document.addEventListener("DOMContentLoaded", function(){

    //Drag Sliders Config
    var all_drag_sliders = document.querySelectorAll(".simple-slider[drag='yes'], .simple-slider[drag='true']")
    for(var i = 0; i < all_drag_sliders.length; i++){

        let this_slider = all_drag_sliders[i];
        let drag_speed = this_slider.getAttribute("speed");
        drag_speed = parseInt(drag_speed)

        if(is_device_touch()){
            this_slider.setAttribute("is-touch", "yes");
        }

        this_slider.setAttribute("draggable", "true");


        this_slider.addEventListener("dragstart", function(e){

            var this_sl = this;

            var tmp = e.clientX;
            this_sl.setAttribute("user-mouse-mx", tmp);
            this_sl.classList.add("grabbing")
        })

        this_slider.addEventListener("dragover", function(e, g=''){

            var this_sl = this;

            var tmp_x = this_sl.getAttribute("user-mouse-mx");
            var tmp = e.clientX;

            var inner = this_sl.querySelector(".simple-slider-inner");
            var cur_scroll = inner.scrollLeft;

            if (tmp > tmp_x) {
                g = cur_scroll - drag_speed;
            } else g = cur_scroll + drag_speed;

            inner.scrollLeft = g;
        })

        this_slider.addEventListener("dragend", function(){
            var this_sl = this;

            this_sl.classList.remove("grabbing")
        })

    }
    /***/

})